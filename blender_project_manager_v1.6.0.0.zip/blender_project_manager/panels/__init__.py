from . import project_panel

def register():
    project_panel.register()

def unregister():
    project_panel.unregister()