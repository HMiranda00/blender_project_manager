import bpy
import os
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty
from ..utils import create_project_structure, setup_collection_settings, setup_role_world
from ..utils.version_control import create_first_wip

# Importando a função para obter preferências
try:
    from ..utils import get_addon_preferences
except ImportError:
    from .. import get_addon_preferences

class PROJECTMANAGER_OT_create_shot(Operator):
    """Creates a new shot in the current project"""
    bl_idname = "project.create_shot"
    bl_label = "Create New Shot"
    
    shot_name: StringProperty(name="Shot Name", default="")
    role_name: StringProperty(name="Role Name", default="", options={'HIDDEN'})
    selected_roles: BoolProperty(name="Selected Roles", default=True, options={'HIDDEN'})
    
    # Propriedades dinâmicas que serão criadas em invoke
    use_ANIMATION: BoolProperty(name="ANIMATION", default=True)
    use_LOOKDEV: BoolProperty(name="LOOKDEV", default=True)
    use_LAYOUT: BoolProperty(name="LAYOUT", default=True)
    
    def invoke(self, context, event):
        # Populate roles from preferences
        self.roles = []
        prefs = get_addon_preferences(context)
        if prefs:
            for role in prefs.role_mappings:
                # Como já temos as propriedades básicas definidas estaticamente,
                # vamos apenas usá-las e não tentar criá-las dinamicamente
                # setattr(self, f"use_{role.role_name}", BoolProperty(name=role.role_name, default=True))
                self.roles.append(role.role_name)
        
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        
        layout.prop(self, "shot_name")
        
        # Show roles
        box = layout.box()
        box.label(text="Create files for roles:")
        
        prefs = get_addon_preferences(context)
        if prefs:
            for role in prefs.role_mappings:
                try:
                    # Tentar acessar a propriedade se ela existir
                    prop_name = f"use_{role.role_name}"
                    if hasattr(self, prop_name):
                        box.prop(self, prop_name, text=role.role_name)
                    else:
                        # Caso contrário, mostrar uma mensagem informativa
                        box.label(text=f"{role.role_name} (role não configurado)")
                except Exception as e:
                    box.label(text=f"Erro ao mostrar {role.role_name}: {str(e)}")
    
    def execute(self, context):
        if not self.shot_name:
            self.report({'ERROR'}, "Shot name cannot be empty")
            return {'CANCELLED'}
            
        if not context.scene.current_project:
            self.report({'ERROR'}, "No active project selected")
            return {'CANCELLED'}
            
        # Check if we have access to preferences
        prefs = get_addon_preferences(context)
        if not prefs:
            self.report({'ERROR'}, "Could not access addon preferences")
            return {'CANCELLED'}
            
        # Get project info
        project_path = context.scene.current_project
        project_name = os.path.basename(project_path.rstrip(os.sep))
        
        # Collect enabled roles
        enabled_roles = []
        for role in prefs.role_mappings:
            try:
                prop_name = f"use_{role.role_name}"
                if hasattr(self, prop_name) and getattr(self, prop_name):
                    enabled_roles.append(role.role_name)
            except:
                # Skip roles that don't have properties
                pass
                
        # Check if any roles are enabled
        if not enabled_roles:
            self.report({'ERROR'}, "No roles selected for creation")
            return {'CANCELLED'}
            
        # Create shot folder structure
        from ..panels.project_panel import PROJECT_PT_Panel
        panel = PROJECT_PT_Panel(context)
        
        result = panel.create_shot(context, self.shot_name, enabled_roles)
        if not result:
            self.report({'ERROR'}, "Failed to create shot")
            return {'CANCELLED'}
            
        # Set the current shot in the scene
        context.scene.current_shot = self.shot_name
        
        self.report({'INFO'}, f"Created shot {self.shot_name} with roles: {', '.join(enabled_roles)}")
        return {'FINISHED'}
        
def register():
    bpy.utils.register_class(PROJECTMANAGER_OT_create_shot)
        
def unregister():
    bpy.utils.unregister_class(PROJECTMANAGER_OT_create_shot)