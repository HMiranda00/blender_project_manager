import bpy
import os
from bpy.types import Operator
from bpy.props import StringProperty
from ..utils import save_current_file
from ..utils.cache import DirectoryCache

# Importando a função para obter preferências
try:
    from ..utils import get_addon_preferences
except ImportError:
    from .. import get_addon_preferences

class PROJECTMANAGER_OT_create_role_file(Operator):
    bl_idname = "project.create_role_file"
    bl_label = "Criar Arquivo do Cargo"
    bl_description = "Criar um novo arquivo para este cargo"
    
    role_name: StringProperty(name="Role Name", default="")
    
    def execute(self, context):
        try:
            if not context.scene.current_project:
                self.report({'ERROR'}, "Nenhum projeto ativo selecionado")
                return {'CANCELLED'}
                
            if not context.scene.current_shot:
                self.report({'ERROR'}, "Nenhum shot ativo selecionado")
                return {'CANCELLED'}
                
            # Obter preferências do addon
            prefs = get_addon_preferences(context)
            if not prefs:
                self.report({'ERROR'}, "Não foi possível acessar as preferências do addon")
                return {'CANCELLED'}
                
            # Obter informações do projeto e shot
            project_path = context.scene.current_project
            shot_name = context.scene.current_shot
            
            # Verificar se o diretório do role existe, se não, criar
            role_path = os.path.join(project_path, "SHOTS", shot_name, self.role_name)
            if not os.path.exists(role_path):
                os.makedirs(role_path, exist_ok=True)
                
            # Criar diretório WIP
            wip_path = os.path.join(role_path, "WIP")
            if not os.path.exists(wip_path):
                os.makedirs(wip_path, exist_ok=True)
                
            # Criar diretório PUBLISH
            publish_path = os.path.join(role_path, "PUBLISH")
            if not os.path.exists(publish_path):
                os.makedirs(publish_path, exist_ok=True)
                
            # Criar um novo arquivo .blend
            # Limpar a cena atual
            bpy.ops.wm.read_homefile(app_template="")
            
            # Configurar coleções e outras configurações iniciais
            # Aqui você pode adicionar lógica para configurar o arquivo conforme o role
            
            # Salvar o arquivo
            project_name = os.path.basename(project_path.rstrip(os.sep))
            filename = f"{project_name}_{shot_name}_{self.role_name}_v001.blend"
            filepath = os.path.join(wip_path, filename)
            
            bpy.ops.wm.save_as_mainfile(filepath=filepath)
            
            # Atualizar as informações no contexto
            context.scene.current_project = project_path
            context.scene.current_shot = shot_name
            context.scene.current_role = self.role_name
            
            # Invalidar o cache do diretório
            if context.scene.current_project:
                project_dir = os.path.dirname(context.scene.current_project)
                DirectoryCache.invalidate(project_dir)
            
            self.report({'INFO'}, f"Arquivo para o cargo {self.role_name} criado com sucesso")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao criar arquivo do cargo: {str(e)}")
            return {'CANCELLED'}

def register():
    bpy.utils.register_class(PROJECTMANAGER_OT_create_role_file)

def unregister():
    bpy.utils.unregister_class(PROJECTMANAGER_OT_create_role_file) 