import bpy
import os
import re
import datetime
import glob
from .. import utils

# Importando a função para obter preferências
try:
    from ..utils import get_addon_preferences
except ImportError:
    try:
        from .. import get_addon_preferences
    except ImportError:
        def get_addon_preferences(context=None):
            if context is None:
                context = bpy.context
            try:
                # Primeiro tenta o nome completo da extensão
                for addon_name in context.preferences.addons.keys():
                    if 'blender_project_manager' in addon_name:
                        return context.preferences.addons[addon_name].preferences
                
                # Tenta o nome legado
                return context.preferences.addons['blender_project_manager'].preferences
            except Exception:
                print("[BPM] Não foi possível acessar as preferências do addon")
                return None

def get_wip_path(context, project_path, project_name, shot_name, role_name):
    """Get the WIP path for a specific shot and role"""
    
    prefs = get_addon_preferences(context)
    if not prefs:
        return ""
        
    _, workspace_path, _ = utils.get_project_info(project_path, prefs.use_fixed_root)
    
    wip_folder = os.path.join(workspace_path, "SHOTS", shot_name, role_name, "WIP")
    os.makedirs(wip_folder, exist_ok=True)
    
    # Get current date for versioning
    today = datetime.datetime.now().strftime("%Y%m%d")
    
    # Find latest version for today
    pattern = os.path.join(wip_folder, f"{project_name}_{shot_name}_{role_name}_{today}_v*.blend")
    existing_files = glob.glob(pattern)
    
    if existing_files:
        # Extract versions from file names
        versions = []
        for file in existing_files:
            match = re.search(r'_v(\d+)\.blend$', file)
            if match:
                versions.append(int(match.group(1)))
        
        # Get next version
        next_version = max(versions) + 1 if versions else 1
    else:
        next_version = 1
    
    # Create file name
    file_name = f"{project_name}_{shot_name}_{role_name}_{today}_v{next_version:03d}.blend"
    wip_path = os.path.join(wip_folder, file_name)
    
    return wip_path

def create_first_wip(context, project_path, project_name, shot_name, role_name):
    """Create and save the first WIP file for a new shot"""
    
    prefs = get_addon_preferences(context)
    if not prefs:
        return False, "Não foi possível acessar as preferências do addon"
        
    wip_path = get_wip_path(context, project_path, project_name, shot_name, role_name)
    
    # Create a new .blend file
    try:
        # Create a new Blender file
        bpy.ops.wm.read_homefile(app_template="")
        
        # Save the file
        bpy.ops.wm.save_as_mainfile(filepath=wip_path)
        
        return True, wip_path
    except Exception as e:
        return False, str(e)

def get_latest_wip(context, role_name):
    """Get the latest WIP version for a specific role"""
    try:
        # Obter informações do projeto atual
        project_path = context.scene.current_project
        shot_name = context.scene.current_shot
        
        # Se o shot ou projeto não estiverem definidos, retorna None
        if not project_path or not shot_name:
            return None, 0
            
        # Obter preferências do addon
        prefs = get_addon_preferences(context)
        if not prefs:
            return None, 0
            
        # Obter informações do projeto
        project_name, workspace_path, _ = utils.get_project_info(project_path, prefs.use_fixed_root)
        
        # Construir o caminho para a pasta WIP
        wip_folder = os.path.join(workspace_path, "SHOTS", shot_name, role_name, "WIP")
        if not os.path.exists(wip_folder):
            return None, 0
        
        # Buscar a versão mais recente
        latest_version = 0
        latest_file = None
        
        for file in os.listdir(wip_folder):
            if file.endswith(".blend"):
                try:
                    # Extrair o número de versão do nome do arquivo
                    version_part = file.split("_v")[-1].split(".")[0]
                    if version_part.isdigit():
                        version = int(version_part)
                        if version > latest_version:
                            latest_version = version
                            latest_file = file
                except:
                    # Ignora arquivos que não seguem o padrão de nomeação
                    pass
        
        if latest_file:
            latest_path = os.path.join(wip_folder, latest_file)
            return latest_path, latest_version
        else:
            return None, 0
            
    except Exception as e:
        print(f"Erro ao buscar a versão WIP mais recente: {str(e)}")
        return None, 0 