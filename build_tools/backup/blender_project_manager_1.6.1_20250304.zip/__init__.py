"""
Blender Project Manager
Addon for project management and organization in animation and VFX pipelines
"""

# Mantido para compatibilidade com versões anteriores do Blender
bl_info = {
    "name": "Blender Project Manager",
    "author": "Henrique Miranda",
    "version": (1, 6, 1),
    "blender": (2, 80, 0),
    "location": "N-Panel",
    "description": "Addon for project management and organization",
    "category": "Project Management"
}

import bpy
import os
import sys
import time
from bpy.props import StringProperty, BoolProperty, EnumProperty, CollectionProperty, IntProperty
from . import operators
from . import panels
from . import preferences
from . import handlers

# Flag para controlar a inicialização
_preferences_initialized = False
_preferences_timer = None

# Função para verificar a versão do Blender
def check_blender_version():
    """Verifica se está rodando no Blender 4.0+ com sistema de extensões"""
    version = bpy.app.version
    return version[0] >= 4

# Função para obter o nome do addon ou extensão
def get_addon_name():
    """
    Determina o nome do addon ou extensão para uso nas APIs do Blender
    """
    module_path = os.path.dirname(os.path.abspath(__file__))
    print(f"[BPM] Module path: {module_path}")
    
    # Determinar se estamos rodando como extensão
    is_extension = check_blender_version() and 'extensions' in module_path
    
    if is_extension:
        print(f"[BPM] Running as extension - trying to find full extension name")
        
        # Tenta extrair o nome completo da extensão do caminho
        extension_name = None
        
        # Método 1: Extração direta do caminho
        if 'user_default' in module_path:
            extension_name = 'bl_ext.user_default.blender_project_manager'
            print(f"[BPM] Detected 'user_default' in path")
        elif 'blender_org' in module_path:
            extension_name = 'bl_ext.blender_org.blender_project_manager'
            print(f"[BPM] Detected 'blender_org' in path")
        
        # Método 2: Extração baseada na estrutura de diretórios
        if not extension_name:
            parts = module_path.split('extensions')
            if len(parts) > 1:
                ext_path = parts[1].strip('\\/')
                components = ext_path.split('\\/')
                if len(components) >= 2:
                    extension_name = f'bl_ext.{components[0]}.{components[1]}'
                    print(f"[BPM] Determined extension name from path: {extension_name}")
        
        # Método 3: Verificar quais extensões estão registradas e encontrar a nossa
        try:
            for ext_id in bpy.context.preferences.addons.keys():
                if 'blender_project_manager' in ext_id:
                    print(f"[BPM] Found registered extension name: {ext_id}")
                    return ext_id
        except Exception as e:
            print(f"[BPM] Error checking registered addons: {str(e)}")
        
        # Se encontramos um nome válido, use-o
        if extension_name:
            return extension_name
            
        # Método 4: Nome base + prefixo padrão como último recurso
        return 'bl_ext.user_default.blender_project_manager'
    else:
        # Usando o nome do diretório como o nome do addon para o modo legado
        addon_name = os.path.basename(module_path)
        return addon_name

# Função para obter acesso às preferências do addon
def get_addon_preferences(context=None):
    """Obtém as preferências do addon, independente do modo de execução (addon ou extensão)"""
    if context is None:
        context = bpy.context
    
    addon_name = get_addon_name()
    
    # Diferenciando entre modo extensão (Blender 4.0+) e modo addon legado
    if check_blender_version():
        # No modo extensão, as preferências podem estar em formato diferente
        try:
            # Tenta acessar diretamente
            if addon_name in context.preferences.addons:
                print(f"[BPM] Encontradas preferências usando nome exato: {addon_name}")
                return context.preferences.addons[addon_name].preferences
        except Exception as e:
            print(f"[BPM] Erro ao tentar acessar preferências diretamente: {str(e)}")
            
        # Se não encontrou, busca por substring
        try:
            # Extensões podem não estar no dicionário addons com o nome exato
            for ext_id in context.preferences.addons.keys():
                if addon_name in ext_id or ext_id.endswith(addon_name):
                    print(f"[BPM] Encontradas preferências usando substring match: {ext_id}")
                    return context.preferences.addons[ext_id].preferences
                    
            # Tenta procurar por 'blender_project_manager' em qualquer formato
            for ext_id in context.preferences.addons.keys():
                if 'blender_project_manager' in ext_id:
                    print(f"[BPM] Encontradas preferências com nome base: {ext_id}")
                    return context.preferences.addons[ext_id].preferences
            
            # Se ainda não encontrou, tenta o formato padrão para extensões do usuário
            extension_id = f"bl_ext.user_default.blender_project_manager"
            if extension_id in context.preferences.addons:
                print(f"[BPM] Encontradas preferências usando id padrão: {extension_id}")
                return context.preferences.addons[extension_id].preferences
                
            # Caso último recurso, tente outras formas conhecidas
            for fallback_id in ["bl_ext.user_default.blender_project_manager", 
                               "bl_ext.blender_org.blender_project_manager", 
                               "blender_project_manager"]:
                if fallback_id in context.preferences.addons:
                    print(f"[BPM] Encontradas preferências com fallback id: {fallback_id}")
                    return context.preferences.addons[fallback_id].preferences
                    
            # Lista todos os addons registrados para debug
            print(f"[BPM] ADDONS REGISTRADOS ({len(context.preferences.addons)}):")
            for idx, ext_id in enumerate(context.preferences.addons.keys()):
                print(f"[BPM]   {idx+1}. {ext_id}")
            
            # Se ainda não encontrou, retorna None sem lançar exceção
            print(f"[BPM] Nenhuma preferência encontrada após todas as tentativas")
            return None
        except Exception as e:
            print(f"[BPM] Erro ao buscar preferências: {str(e)}")
            return None
    else:
        # Modo legado para Blender < 4.0
        try:
            return context.preferences.addons[addon_name].preferences
        except KeyError:
            return None

# Função para inicializar as preferências de forma segura usando um timer
def init_preferences_callback():
    """Inicializa as preferências com segurança após um breve atraso"""
    global _preferences_initialized, _preferences_init_attempts
    
    # Controla o número de tentativas para evitar loops infinitos
    if not hasattr(init_preferences_callback, 'attempt_count'):
        init_preferences_callback.attempt_count = 0
    
    # Limite as tentativas para evitar loops infinitos
    init_preferences_callback.attempt_count += 1
    if init_preferences_callback.attempt_count > 3:
        print(f"[BPM] Máximo de tentativas de inicialização atingido. Cancelando timer.")
        _preferences_initialized = True
        return None
    
    # Evita múltiplas inicializações
    if _preferences_initialized:
        return None
    
    print(f"[BPM] Initializing preferences... (Tentativa {init_preferences_callback.attempt_count})")
    module_path = os.path.dirname(os.path.abspath(__file__))
    print(f"[BPM] Module path: {module_path}")
    
    # Determina o modo de execução e o nome do addon
    addon_name = get_addon_name()
    
    # Tenta acessar as preferências para verificar se estão disponíveis
    try:
        prefs = get_addon_preferences(bpy.context)
        if prefs is not None:
            print(f"[BPM] Preferences acessadas com sucesso para: {addon_name}")
            _preferences_initialized = True
            return None
        else:
            print(f"[BPM] Preferências não foram encontradas para: {addon_name}")
            # Agenda uma nova tentativa após 2 segundos
            if init_preferences_callback.attempt_count < 3:
                print(f"[BPM] Agendando nova tentativa em 2 segundos...")
                return 2.0
            else:
                print(f"[BPM] Número máximo de tentativas atingido.")
                _preferences_initialized = True
                return None
    except Exception as e:
        print(f"[BPM] Erro ao tentar acessar as preferências: {str(e)}")
        if init_preferences_callback.attempt_count < 3:
            print(f"[BPM] Agendando nova tentativa em 2 segundos...")
            return 2.0
        else:
            print(f"[BPM] Número máximo de tentativas atingido.")
            _preferences_initialized = True
            return None

def register():
    global _preferences_timer
    
    print("[BPM] ========================================")
    print("[BPM] REGISTERING BLENDER PROJECT MANAGER")
    print(f"[BPM] Python version: {sys.version}")
    print(f"[BPM] Blender version: {bpy.app.version_string}")
    
    module_path = os.path.dirname(os.path.abspath(__file__))
    print(f"[BPM] Running from: {module_path}")
    print(f"[BPM] Module path: {module_path}")
    
    # Registrar as pastas utils
    from . import utils
    
    # Mostrar a detecção do modo
    if check_blender_version():
        print(f"[BPM] Running as extension - using fixed name")
        addon_name = get_addon_name()
        print(f"[BPM] Extension/Addon name detected: {addon_name}")
        
        # Verificar se as preferências já estão disponíveis
        try:
            prefs = get_addon_preferences(bpy.context)
            if prefs:
                print(f"[BPM] Preferências já estão disponíveis durante o registro")
            else:
                print(f"[BPM] Preferências ainda não estão disponíveis durante o registro")
        except Exception as e:
            print(f"[BPM] Erro ao verificar preferências durante o registro: {str(e)}")
    else:
        print(f"[BPM] Running as legacy addon")
    
    print(f"[BPM] Importing utils...")
    
    # Registrar módulos
    print(f"[BPM] Registering preferences...")
    preferences.register()
    
    print(f"[BPM] Registering operators...")
    operators.register()
    
    print(f"[BPM] Registering panels...")
    panels.register()
    
    # Registrar handlers
    print(f"[BPM] Registering handlers...")
    handlers.register_handlers()
    
    # Registrar propriedades da cena
    print(f"[BPM] Registering scene properties...")
    bpy.types.Scene.current_project = StringProperty(
        name="Current Project",
        description="Path to the current project",
        default="",
        subtype='DIR_PATH'
    )
    
    bpy.types.Scene.current_shot = StringProperty(
        name="Current Shot",
        description="Name of the current shot",
        default=""
    )
    
    bpy.types.Scene.current_role = StringProperty(
        name="Current Role",
        description="Name of the current role",
        default=""
    )
    
    bpy.types.Scene.previous_file = StringProperty(
        name="Previous File",
        description="Path to the previous file before opening assembly",
        default=""
    )
    
    bpy.types.Scene.show_asset_manager = BoolProperty(name="Show Asset Manager")
    bpy.types.Scene.show_role_status = BoolProperty(name="Show Role Status")
    
    # Registra um timer para inicializar as preferências com segurança
    print(f"[BPM] Scheduling preferences initialization...")
    try:
        # Em versões mais recentes do Blender, não podemos verificar diretamente se um callback está registrado
        # Portanto, apenas registramos o timer se ele ainda não estiver definido
        if not _preferences_timer:
            _preferences_timer = bpy.app.timers.register(init_preferences_callback, first_interval=1.0)
            print(f"[BPM] Timer for preferences initialization registered")
    except Exception as e:
        print(f"[BPM] Error registering preferences timer: {str(e)}")
    
    # Verificar se os painéis foram registrados
    print(f"[BPM] Checking if panels are registered:")
    for panel in dir(bpy.types):
        if panel.startswith("VIEW3D_PT_project_management"):
            panel_cls = getattr(bpy.types, panel)
            if hasattr(panel_cls, "bl_label"):
                print(f"[BPM] - Panel registered: {panel} - {panel_cls.bl_label}")
    
    print("[BPM] REGISTRATION COMPLETE")
    print("[BPM] ========================================")

def unregister():
    global _preferences_timer
    
    print("[BPM] ========================================")
    print("[BPM] UNREGISTERING BLENDER PROJECT MANAGER")
    
    # Cancela o timer de inicialização se ainda estiver ativo
    try:
        if _preferences_timer:
            print("[BPM] Unregistered preference initialization timer")
            bpy.app.timers.unregister(_preferences_timer)
            _preferences_timer = None
    except Exception as e:
        print(f"[BPM] Error unregistering timer: {str(e)}")
        _preferences_timer = None
    
    # Parar os handlers
    print("[BPM] Unregistering handlers...")
    handlers.unregister_handlers()
    
    # Remover propriedades da cena
    print("[BPM] Removing scene properties...")
    del bpy.types.Scene.current_project
    del bpy.types.Scene.current_shot
    del bpy.types.Scene.current_role
    del bpy.types.Scene.previous_file
    del bpy.types.Scene.show_asset_manager
    del bpy.types.Scene.show_role_status
    
    print("[BPM] Unregistering panels...")
    panels.unregister()
    
    print("[BPM] Unregistering operators...")
    operators.unregister()
    
    print("[BPM] Unregistering preferences...")
    preferences.unregister()
    
    print("[BPM] UNREGISTRATION COMPLETE")
    print("[BPM] ========================================")