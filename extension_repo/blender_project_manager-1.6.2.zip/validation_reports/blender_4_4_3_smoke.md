# Blender Smoke Report - 4.4.3

- Date: 2026-03-03T15:59:02
- Blender: 4.4.3
- Build hash: 802179c51ccc
- Temp root: `C:\Users\miranda\AppData\Local\Temp\bpm_smoke_1hi57yl_`
- Project path: `C:\Users\miranda\AppData\Local\Temp\bpm_smoke_1hi57yl_\PRJ001_SMOKE`

## Results

- PASS: Addon register/unregister cycle
- PASS: Create project (flexible root)
- PASS: Create shot + role initial files
- PASS: New WIP and publish update
- PASS: Open and rebuild assembly
- PASS: Create asset (mark only)

## Detailed Errors

- None
