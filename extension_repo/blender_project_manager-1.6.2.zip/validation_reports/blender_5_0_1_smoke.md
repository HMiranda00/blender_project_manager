# Blender Smoke Report - 5.0.1

- Date: 2026-03-03T17:16:35
- Blender: 5.0.1
- Build hash: a3db93c5b259
- Temp root: `C:\Users\miranda\AppData\Local\Temp\bpm_smoke_3h5fiir3`
- Project path: `C:\Users\miranda\AppData\Local\Temp\bpm_smoke_3h5fiir3\PRJ001_SMOKE`

## Results

- PASS: Addon register/unregister cycle
- PASS: Create project (flexible root)
- PASS: Create shot + role initial files
- PASS: New WIP and publish update
- PASS: Open and rebuild assembly
- PASS: Create asset (mark only)

## Detailed Errors

- None
