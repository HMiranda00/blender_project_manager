# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [1.6.2] - 2026-03-03

### Added
- 

### Changed
- 

### Fixed
- 

## [1.6.1] - 2026-03-03

### Added
- 

### Changed
- 

### Fixed
- 

### Added
- 

### Changed
- 

### Fixed
- 


